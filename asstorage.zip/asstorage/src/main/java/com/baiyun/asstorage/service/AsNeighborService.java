package com.baiyun.asstorage.service;

public interface AsNeighborService {
    String setFalg(boolean flag);

    void buildAsNeigh();

    Integer getHandleCount();

    String updateLoc();

    void businessRelationship();
}
